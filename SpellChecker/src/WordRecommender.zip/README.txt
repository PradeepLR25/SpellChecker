Ways to Improve spell checking:

Scoring could be improved.  
1) Identify incorrect words
2) determine the character that is mismatched from a dictonary word or list of dictionary words.
3) suggest a replacement word by replacing word with nearby characters on keyboard for that particular letter.


eg: thpe
Identify "h" as the incorrect letter for a list of words.
Determine that "h" character is near the "y" or "u" character 
Add the suggestions of "type" and "tupe"

For words with extra characters like texttttttttt, realize that a string of repeated characters are that are more than 2
is present and remove all extra ones.  so textttttt would be textt, and words that have triple "o" like
looop would be corrected to loop.